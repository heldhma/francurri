# Responsive Resume

A Pen created on CodePen.io. Original URL: [https://codepen.io/jhawes/pen/oNKzYr](https://codepen.io/jhawes/pen/oNKzYr).

Responsive Resume built in Sass